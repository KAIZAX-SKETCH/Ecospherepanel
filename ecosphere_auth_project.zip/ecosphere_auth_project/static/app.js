const screens = [...document.querySelectorAll('.screen')];
let phoneNumber = '';

function showScreen(id) {
  screens.forEach(s => s.classList.toggle('active', s.id === id));
  document.querySelectorAll('.notice').forEach(n => { n.classList.remove('show'); n.textContent = ''; });
}
function notice(id, message, type='info') {
  const el = document.getElementById(id);
  if (!el) return;
  el.className = 'notice show ' + type;
  el.textContent = message;
}
async function api(url, data={}) {
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type':'application/json',
      'X-CSRFToken': document.querySelector('meta[name="csrf-token"]')?.content || ''
    },
    credentials: 'same-origin',
    body: JSON.stringify(data)
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || !payload.ok) throw new Error(payload.error || 'Request failed. Please try again.');
  return payload;
}
document.querySelectorAll('[data-back]').forEach(btn => btn.addEventListener('click', () => showScreen(btn.dataset.back)));
document.getElementById('phoneBtn').addEventListener('click', () => showScreen('phoneScreen'));
document.getElementById('phoneForm').addEventListener('submit', async e => {
  e.preventDefault();
  phoneNumber = document.getElementById('phone').value.trim();
  const btn = e.submitter;
  btn.disabled = true;
  try {
    const result = await api('/api/send-otp', {phone: phoneNumber});
    document.getElementById('phonePreview').textContent = phoneNumber;
    showScreen('otpScreen');
    notice('otpNotice', result.message);
  } catch (err) {
    notice('phoneNotice', err.message, 'error');
  } finally { btn.disabled = false; }
});
document.getElementById('otpForm').addEventListener('submit', async e => {
  e.preventDefault();
  const btn = e.submitter; btn.disabled = true;
  try {
    const result = await api('/api/verify-otp', {otp: document.getElementById('otp').value.trim()});
    notice('otpNotice', result.message);
    showScreen('passwordScreen');
  } catch (err) {
    notice('otpNotice', err.message, 'error');
  } finally { btn.disabled = false; }
});
document.getElementById('passwordForm').addEventListener('submit', async e => {
  e.preventDefault();
  const password = document.getElementById('password').value;
  const confirm = document.getElementById('confirmPassword').value;
  if (password.length < 8) return notice('passwordNotice', 'Password must contain at least 8 characters.', 'error');
  if (password !== confirm) return notice('passwordNotice', 'Passwords do not match.', 'error');
  const btn = e.submitter; btn.disabled = true;
  try {
    await api('/api/signup', {password});
    showScreen('signedInScreen');
  } catch (err) {
    notice('passwordNotice', err.message, 'error');
  } finally { btn.disabled = false; }
});
document.getElementById('returnHome').addEventListener('click', () => showScreen('homeScreen'));

function handleGoogleCredential(response) {
  if (!response?.credential) {
    notice('globalNotice', 'Google did not return a sign-in credential. Please try again.', 'error');
    return;
  }
  api('/api/google', {credential: response.credential})
    .then(() => showScreen('signedInScreen'))
    .catch(err => notice('globalNotice', err.message, 'error'));
}

async function setupGoogle() {
  const fallback = document.getElementById('googleBtn');
  try {
    const response = await fetch('/api/config', {credentials: 'same-origin'});
    if (!response.ok) throw new Error('Could not load sign-in settings.');
    const cfg = await response.json();
    if (!cfg.google_client_id) {
      fallback.addEventListener('click', () => notice(
        'globalNotice',
        'Google sign-up is not configured yet. Add GOOGLE_CLIENT_ID to .env and register this site in Google Cloud Console.',
        'warn'
      ));
      return;
    }

    const loadGsi = () => {
      if (!window.google?.accounts?.id) {
        notice('globalNotice', 'Google sign-in is still loading. Please try again in a moment.', 'info');
        return;
      }
      try {
        google.accounts.id.initialize({
          client_id: cfg.google_client_id,
          callback: handleGoogleCredential,
          auto_select: false,
          cancel_on_tap_outside: true
        });
        const host = document.getElementById('googleSignInButton');
        host.replaceChildren();
        host.style.display = 'block';
        google.accounts.id.renderButton(host, {
          theme: 'outline', size: 'large', shape: 'pill',
          text: 'continue_with', width: 280
        });
        fallback.style.display = 'none';
      } catch (err) {
        notice('globalNotice', 'Google sign-in could not initialize. Check your OAuth client configuration.', 'error');
      }
    };

    const existing = document.querySelector('script[data-google-identity]');
    if (window.google?.accounts?.id) {
      loadGsi();
    } else if (existing) {
      existing.addEventListener('load', loadGsi, {once: true});
      existing.addEventListener('error', () => notice('globalNotice', 'Google sign-in could not load. Check your internet connection.', 'error'), {once: true});
    } else {
      const script = document.createElement('script');
      script.src = 'https://accounts.google.com/gsi/client';
      script.async = true;
      script.defer = true;
      script.dataset.googleIdentity = 'true';
      script.onload = loadGsi;
      script.onerror = () => notice('globalNotice', 'Google sign-in could not load. Check your internet connection or browser settings.', 'error');
      document.head.appendChild(script);
    }
  } catch (_) {
    fallback.addEventListener('click', () => notice('globalNotice', 'Could not load Google sign-in settings. Refresh the page and try again.', 'error'));
  }
}
setupGoogle();
